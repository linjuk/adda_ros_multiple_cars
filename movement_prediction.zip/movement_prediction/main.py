#! /usr/bin/python
from tabulate import tabulate
from functions import all_prediction_processing, distance_formula

result_set_A = all_prediction_processing(number_point=10)
result_set_B = all_prediction_processing(number_point=100, apply_power=True, power=0.1)  # 0.1 --> 1/(100/10) = 1/10 = 0.1

# print("\nresult_set_A")
# print tabulate(result_set_A, headers=['Time step', 'Coordinates [x,y]', 'Likelihood(pdf) [left, right, straight]', 'Updated belief [left, right, straight]'])
#
# print("\nresult_set_B")
# print tabulate(result_set_B, headers=['Time step', 'Coordinates [x,y]', 'Likelihood(pdf) [left, right, straight]', 'Updated belief [left, right, straight]'])


result_A=[]
print("Result set A (not powered by any degree)")
for time in range(0, len(result_set_A)):
    result_A.append(result_set_A[time])
    print tabulate([result_set_A[time]], headers=['\nTime step', '\nCoordinates [x,y]', '\nLikelihood(pdf) [left, right, straight]', '\nUpdated belief [left, right, straight]'])

result_B=[]
print("Result set B (powered by degree)")
for time in range(0, len(result_set_B)):
    if time % 11 == 0:
        result_B.append(result_set_B[time])
        print tabulate([result_set_B[time]], headers=['\nTime step', '\nCoordinates [x,y]', '\nLikelihood(pdf) [left, right, straight]', '\nUpdated belief [left, right, straight]'])

print("-------------------------")
print("-------------------------")

for i in range(len(result_A)):
    # print(result_A[i][0], result_A[i][2])
    # print(result_B[i][0], result_B[i][2])
    print("{} step in 10 step trajectory. Updated belief[left, right, straight]: {}".format(result_A[i][0],result_A[i][3]))
    print("{} step in 100 step trajectory. Updated belief[left, right, straight]: {}".format(result_B[i][0],result_B[i][3]))
    print("-------------------------")




# # nested loop to compare each value of result set A with each value of result set B
# # and use that comparison to test out different conditions like same coordinates, similar coordinates etc.
# for time_step_A in range(len(result_set_A)):
#     for time_step_B in range(len(result_set_B)):
#
#         # testing condition 1: find same coordinates
#         matching_coordinates = set(result_set_A[time_step_A][1]).intersection(result_set_B[time_step_B][1])
#         if len(matching_coordinates) > 0:
#             print("\nMatch found, result_set_A point {} and result_set_B point {}".format(time_step_A, time_step_B))
#             print tabulate([result_set_A[time_step_A], result_set_B[time_step_B]], headers=['Time step', 'Coordinates [x,y]', 'Likelihood(pdf) [left, right, straight]', 'Updated belief [left, right, straight]'])
#             break
#
#         # testing condition 2: find similar coordinates i.e distance < 0.05, 0.009, 0.1 etc.
#         distance_between_coordinates = distance_formula(result_set_A[time_step_A][1], result_set_B[time_step_B][1])
#         if len(matching_coordinates) == 0 and distance_between_coordinates < 0.1:
#             print("\nSimilar coordinates found, result_set_A point {} and result_set_B point {} with a distance of {}".format(time_step_A, time_step_B, distance_between_coordinates))
#             print tabulate([result_set_A[time_step_A], result_set_B[time_step_B]], headers=['Time step', 'Coordinates [x,y]', 'Likelihood(pdf) [left, right, straight]', 'Updated belief [left, right, straight]'])
